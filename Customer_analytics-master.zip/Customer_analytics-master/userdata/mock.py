Account_risk = [
{
	"account_id": "1",
	"account_name" : "webapp",
	"customer_name" : "Rohit",
	"account_risk" : "5% of Pipe is ageing@Account margins are bit lower@Account revenue is not stable@Account has high operation Cost@Competative ratio is bit less"
},
{
	"account_id": "2",
	"account_name" : "virtualciz",
	"customer_name" : "Tanuja",
	"account_risk" : "15% of Pipe is ageing@Account margins are going up and down@Account revenue is not prdictable@Account has Lower operation flow@Competative ratio is not static"
},
{
	"account_id": "3",
	"account_name" : "Mapplezing",
	"customer_name" : "Rasu",
	"account_risk" : "20% of Pipe is ageing@Account margins are range in consitence@Customer are rdeucing day by day@Account has less user interaction@Competative ratio way too low"
},
{
	"account_id": "4",
	"account_name" : "Pinklepack",
	"customer_name" : "Ramya",
	"account_risk" : "30% of Pipe is ageing@Account margins highly instable@Account revenue is very bad@Account has higher operational cost@Competative ratio is almost null"
}
]

account = [
{
	"account_id":"1",
	"account_child":"5",
	"potential":"HP",
	"pipeline":"HP",
	"stage":"Won"
},
{
	"account_id":"1",
	"account_child":"6",
	"potential":"HP",
	"pipeline":"HP",
	"stage":"Won"
},
{
	"account_id":"1",
	"account_child":"7",
	"potential":"LP",
	"pipeline":"LP",
	"stage":"Lost"
},
{
	"account_id":"1",
	"account_child":"8",
	"potential":"HP",
	"pipeline":"LP",
	"stage":"Won"
},
{
	"account_id":"1",
	"account_child":"9",
	"potential":"LP",
	"pipeline":"HP",
	"stage":"Won"
},
{
	"account_id":"2",
	"account_child":"15",
	"potential":"HP",
	"pipeline":"HP",
	"stage":"Won"
},
{
	"account_id":"2",
	"account_child":"16",
	"potential":"HP",
	"pipeline":"HP",
	"stage":"Won"
},
{
	"account_id":"2",
	"account_child":"17",
	"potential":"LP",
	"pipeline":"LP",
	"stage":"Lost"
},
{
	"account_id":"2",
	"account_child":"18",
	"potential":"HP",
	"pipeline":"LP",
	"stage":"Won"
},
{
	"account_id":"2",
	"account_child":"19",
	"potential":"LP",
	"pipeline":"HP",
	"stage":"Won"
},
{
	"account_id":"3",
	"account_child":"25",
	"potential":"HP",
	"pipeline":"HP",
	"stage":"Won"
},
{
	"account_id":"3",
	"account_child":"26",
	"potential":"HP",
	"pipeline":"HP",
	"stage":"Won"
},
{
	"account_id":"3",
	"account_child":"37",
	"potential":"LP",
	"pipeline":"LP",
	"stage":"Lost"
},
{
	"account_id":"3",
	"account_child":"38",
	"potential":"HP",
	"pipeline":"LP",
	"stage":"Won"
},
{
	"account_id":"3",
	"account_child":"39",
	"potential":"LP",
	"pipeline":"HP",
	"stage":"Won"
},
{
	"account_id":"4",
	"account_child":"45",
	"potential":"HP",
	"pipeline":"HP",
	"stage":"Won"
},
{
	"account_id":"4",
	"account_child":"46",
	"potential":"HP",
	"pipeline":"HP",
	"stage":"Won"
},
{
	"account_id":"4",
	"account_child":"47",
	"potential":"LP",
	"pipeline":"LP",
	"stage":"Lost"
},
{
	"account_id":"4",
	"account_child":"48",
	"potential":"HP",
	"pipeline":"LP",
	"stage":"Won"
},
{
	"account_id":"4",
	"account_child":"49",
	"potential":"LP",
	"pipeline":"HP",
	"stage":"Won"
},
]